(** @canonical Synth.Author *)
module Author = Synth__Author


(** @canonical Synth.Gui *)
module Gui = Synth__Gui


(** @canonical Synth.IO *)
module IO = Synth__IO


(** @canonical Synth.Sound *)
module Sound = Synth__Sound


(** @canonical Synth.Sound_state *)
module Sound_state = Synth__Sound_state
