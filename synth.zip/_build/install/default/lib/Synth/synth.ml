(** @canonical Synth.Author *)
module Author = Synth__Author


(** @canonical Synth.Filters *)
module Filters = Synth__Filters


(** @canonical Synth.Gui *)
module Gui = Synth__Gui


(** @canonical Synth.IO *)
module IO = Synth__IO


(** @canonical Synth.Sound *)
module Sound = Synth__Sound
