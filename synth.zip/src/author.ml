let hours_worked = 24
let netIDs = "dsj47, yh797, al882, rlc357"